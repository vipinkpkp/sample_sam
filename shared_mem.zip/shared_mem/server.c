/****************************************************************************************
* Filename : server.c   Code Revision:02
*
* Description :
*       Shared memory server program
*
*By : Jintu Jacob
*26th August , 2019
****************************************************************************************/

#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
struct student {
	char student_name[50];
	int roll_no;
	int marks;
	int flag;
	char brk[20];
};

int main(void)
{
	key_t key = ftok("shmfile", 65);
	int shmid;
	struct student *s1;
	shmid = shmget(key, 1024, 0666 | IPC_CREAT);
	s1 = (struct student *) shmat(shmid, (void *)0, 0);
	strcpy(s1->brk, "continue");
	s1->flag = 1;
	while (1) {
		printf("Enter student name:");
		scanf("%s", s1->student_name);
		printf("Enter roll number:");
		scanf("%d", &(s1->roll_no));
		printf("Enter marks:");
		scanf("%d", &(s1->marks));
		if (strcmp (s1->brk, "break") == 0)
			break;
		else if (strcmp (s1->brk, "continue") == 0)
			continue;
		else {
		printf("%s\n", s1->brk);
		printf("Invalid option\n");
			exit(0);
		}

	}
	shmdt((void *) s1);
	shmctl(shmid, IPC_RMID, NULL);
	return 0;
}


