/****************************************************************************************
* Filename : client.c	Code Revision:02
*
* Description :
*	Shared memory client program
*
*By : Jintu Jacob
*26th August , 2019
****************************************************************************************/
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>
#include<stdlib.h>
#include<unistd.h>

struct student {
	char student_name[50];
	int roll_no;
	int marks;
	int flag;
	char brk[20];
};

int main(void)
{
	key_t key = ftok("shmfile", 65);
	int shmid;
	struct student *s1;
	shmid = shmget(key, 1024, 0666 | IPC_CREAT);
	s1 = (struct student *)shmat(shmid, (void *)0, 0);

	if (s1->flag == 1) {
		while (1) {
			printf("Student name :%s", s1->student_name);
			printf("\nRoll number:%d\n", s1->roll_no);
			printf("Marks:%d\n", s1->marks);
			printf("Press break if you want to stop .Else press continue\n");
			scanf("%s", s1->brk);
			if (strcmp(s1->brk, "break") == 0)
				break;
			else if (strcmp(s1->brk, "continue") == 0)
				continue;
			else {
				printf("Invalid option\n");
				exit(0);
			}
		}
	}
	else {
		printf("No data is present in memory.Please run server program.\n");
	}
	shmdt((void *) s1);
	return 0;
}

